CREATE TABLE IF NOT EXISTS registro (
    id INT PRIMARY KEY,
    nombre VARCHAR(100),
    edad INT
);

INSERT INTO registro (id, nombre, edad) VALUES (1, 'Ana', 22);
INSERT INTO registro (id, nombre, edad) VALUES (2, 'Luis', 30);
INSERT INTO registro (id, nombre, edad) VALUES (3, 'Pedro', 28);
INSERT INTO registro (id, nombre, edad) VALUES (4, 'Lucía', 25);
INSERT INTO registro (id, nombre, edad) VALUES (5, 'Carlos', 35);
